package com.example.hospitalsx.ui.acercade;

import androidx.lifecycle.ViewModel;

public class AcercaDeViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}