package com.example.hospitalsx.ui.listar;

import androidx.lifecycle.ViewModel;

public class ListarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}