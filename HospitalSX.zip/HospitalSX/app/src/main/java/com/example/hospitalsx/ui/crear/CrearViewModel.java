package com.example.hospitalsx.ui.crear;

import androidx.lifecycle.ViewModel;

public class CrearViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}